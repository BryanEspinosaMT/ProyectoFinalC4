import React, { Component } from 'react'

class PageEventos extends Component{
    render(){
        return <div>
            ESTA ES LA PAGINA DE EVENTOS
        </div>
    }
}

export default PageEventos